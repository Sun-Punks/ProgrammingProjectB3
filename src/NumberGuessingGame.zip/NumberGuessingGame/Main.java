import java.util.Random;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    // Set random number equal to a random number between 0 and 100
    Random randNum = new Random();
    int compNum = randNum.nextInt(100);
    // System.out.println(compNum); //delete later

    // Set atttempts equal to 0
    int a = 0;

    // Have user guess a number and save it
    // Print "Welcome to the guessing game! Guess a number between 1 and 100:"
    Scanner s1 = new Scanner(System.in);
    System.out.println("Welcome to the number guessing game! \n Guess a number between 0 and 100");
    int g = s1.nextInt();
    a++;
    // System.out.println(a); //delete later

    // While guess is not equal to random number
    while (compNum != g) {
      // if guess is greater than the random number. print "You guessed (guess). That
      // number is too high, try again:"
      if (g > compNum) {
        System.out.println("You guessed " + g + "\nThat number is too high, try again:");
        a++;
        g = s1.nextInt();
        // System.out.println(a); //delete later
        // If guess is less than the random number. print "You guessed (guess). That
        // number is too low, try again:"
      } else if (g < compNum) {
        System.out.println("You guessed " + g + "\nThat number is too low, try again:");
        // Add one to guess count
        a++;
        g = s1.nextInt();
        // System.out.println(a); //delete later
      }
    }

    // if guess is the random number
    if (g == compNum) {
      // print "You guessed (guess). You got it! You guessed the number in (guesses)
      // tries!"
      System.out.println("You guessed " + g + "\nYou got it! You guessed the number in " + a + " tries!");
    }
    s1.close();
  }
}